﻿namespace Summit.Repositories
{
    public class Class1
    {

    }
}