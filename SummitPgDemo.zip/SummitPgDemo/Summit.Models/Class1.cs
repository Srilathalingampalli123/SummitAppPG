﻿namespace Summit.Models
{
    public class Class1
    {

    }
}